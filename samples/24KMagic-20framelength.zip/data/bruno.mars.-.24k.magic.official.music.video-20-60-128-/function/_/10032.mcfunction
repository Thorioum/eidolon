# 2C-CLIENT PROPERTY

execute run stopsound @a[tag=!nomusic,tag=!nm] record
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.69985359 0.16040467
playsound minecraft:block.cherry_wood_button.click_on record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.83162678 0.14785534
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.17870722 0.12700044
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 2.00000000 0.07732527
playsound minecraft:block.note_block.bass record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.95652174 0.07706713
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 2.00000000 0.04895696
playsound minecraft:entity.item.pickup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.59086673 0.04545444
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.86230248 0.03697450
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.33944954 0.03045926
playsound minecraft:block.ender_chest.open record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.58381503 0.02994271
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.13669065 0.02918283
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.13669065 0.02670630
playsound minecraft:entity.player.levelup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.68131868 0.02491441
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 2.00000000 0.02167678
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.67018470 0.02085968
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.95652174 0.02075036
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.95652174 0.02039902
playsound minecraft:entity.item.pickup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.91457286 0.02032487
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.63731170 0.02020120
playsound minecraft:entity.firework_rocket.large_blast record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.52352232 0.01910663
playsound minecraft:entity.item.pickup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.51052348 0.01640918
playsound minecraft:entity.player.levelup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.54916242 0.01568951
playsound minecraft:entity.copper_golem_weathered.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.65036675 0.01551326
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.13669065 0.01512863
playsound minecraft:entity.copper_golem_weathered.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.73684211 0.01431234
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.83216783 0.01217940
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.17870722 0.01174033
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.58381503 0.01109784
playsound minecraft:entity.bogged.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.59086673 0.01068829
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.22580645 0.01059610
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.70658683 0.00966927
playsound minecraft:entity.zombie_villager.cure record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.22580645 0.00920076
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.87850467 0.00877690
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.83216783 0.00826769
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.27896996 0.00602753

schedule function bruno.mars.-.24k.magic.official.music.video-20-60-128-:_/10033 2t append