# 2C-CLIENT PROPERTY

execute run stopsound @a[tag=!nomusic,tag=!nm] record

schedule function bruno.mars.-.24k.magic.official.music.video-20-60-128-:_/2 2t append