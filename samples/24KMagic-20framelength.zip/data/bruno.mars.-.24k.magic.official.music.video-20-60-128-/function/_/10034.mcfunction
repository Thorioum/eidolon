# 2C-CLIENT PROPERTY

execute run stopsound @a[tag=!nomusic,tag=!nm] record
playsound minecraft:entity.elder_guardian.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.09897611 0.17989795
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.91457286 0.10580563
playsound minecraft:entity.creaking.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.79536680 0.06208858
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.03405573 0.05983144
playsound minecraft:entity.copper_golem_weathered.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.50073783 0.05861068
playsound minecraft:block.note_block.pling record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.65036675 0.04720535
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.40886699 0.04319326
playsound minecraft:entity.creaking.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.95652174 0.03783105
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.77372263 0.03246117
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.13669065 0.03204816
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.78424015 0.02922752
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.83216783 0.02771927
playsound minecraft:block.shulker_box.open record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.33944954 0.02451322
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.09897611 0.02421662
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.73684211 0.02341539
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.27896996 0.02296776
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.83298097 0.02146639
playsound minecraft:entity.item.pickup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.00591716 0.02113482
playsound minecraft:entity.bogged.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.69340974 0.02064581
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.53447144 0.01975174
playsound minecraft:entity.copper_golem_weathered.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.53061224 0.01928588
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.56344773 0.01910801
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.89588378 0.01662227
playsound minecraft:entity.creaking.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.87850467 0.01633239
playsound minecraft:block.anvil.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.59635666 0.01449417
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.06493506 0.01400464
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.09897611 0.01335163
playsound minecraft:entity.copper_golem_weathered.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.50622407 0.01253062
playsound minecraft:block.anvil.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.73684211 0.01200705
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.65989848 0.01162792
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.06493506 0.01109982
playsound minecraft:entity.creaking.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.53061224 0.01102227
playsound minecraft:block.anvil.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.55421687 0.01094802
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.50073783 0.01039390
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.40886699 0.00887063
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.63731170 0.00869403
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.65036675 0.00857279
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.95652174 0.00775375
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 2.00000000 0.00504402

schedule function bruno.mars.-.24k.magic.official.music.video-20-60-128-:_/10035 2t append