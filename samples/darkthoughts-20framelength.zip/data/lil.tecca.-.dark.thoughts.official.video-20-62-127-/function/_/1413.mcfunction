# 2C-CLIENT PROPERTY

execute run stopsound @a[tag=!nomusic,tag=!nm] record
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.69426752 0.47594926
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.00296736 0.35229613
playsound minecraft:block.wooden_button.click_off record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.37078652 0.34996016
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.89320388 0.31300667
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.03105590 0.29768905
playsound minecraft:entity.item.pickup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.56230032 0.20885018
playsound minecraft:entity.firework_rocket.twinkle record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.91183879 0.19358017
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.60381143 0.18393429
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.81724846 0.17545569
playsound minecraft:entity.guardian.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.81724846 0.16540836
playsound minecraft:entity.player.levelup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.51732102 0.16453955
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.27586207 0.14425722
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.83098592 0.13139623
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.55141580 0.12777078
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.13357401 0.12390453
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.33640553 0.11725378
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 2.00000000 0.10830072
playsound minecraft:entity.skeleton_horse.jump_water record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.13357401 0.09267864
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.40594059 0.08842194
playsound minecraft:entity.creaking.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.77148080 0.08560000
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.00296736 0.07630397
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.72668810 0.07227687
playsound minecraft:entity.item.pickup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.71899529 0.06622733
playsound minecraft:entity.player.levelup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.52153110 0.06029513
playsound minecraft:entity.bogged.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.54042847 0.05745925
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.79303675 0.05697337
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.85972851 0.05515823
playsound minecraft:entity.zombie_villager.cure record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.48663102 0.05346901
playsound minecraft:entity.copper_golem_weathered.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.81724846 0.05338836
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.93193717 0.05244480
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.83098592 0.05184247
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.73476112 0.04515351
playsound minecraft:entity.bogged.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.69794721 0.04513095
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.22267206 0.04151300
playsound minecraft:entity.copper_golem_weathered.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.00296736 0.04143313
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.67950481 0.04129728
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.93193717 0.04093260
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.76156584 0.04049378
playsound minecraft:block.anvil.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.62039046 0.03994084
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.59785784 0.03743175
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.84463895 0.03718528
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 2.00000000 0.03565934
playsound minecraft:block.anvil.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.61013444 0.03168308
playsound minecraft:block.anvil.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.66321244 0.03157442
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.63990555 0.03115284
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.06188925 0.03015909
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.33640553 0.02698677
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.17557252 0.02523444
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.69153515 0.02226993
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.78195489 0.02108869
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.95367847 0.01980210

schedule function lil.tecca.-.dark.thoughts.official.video-20-62-127-:_/1414 2t append