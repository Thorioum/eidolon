# 2C-CLIENT PROPERTY

execute run stopsound @a[tag=!nomusic,tag=!nm] record
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.97727273 0.32567310
playsound minecraft:block.note_block.bass record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.50074368 0.25525057
playsound minecraft:entity.guardian.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.89320388 0.12154394
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.56037885 0.11190834
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.09589041 0.09657956
playsound minecraft:block.ender_chest.open record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.48663102 0.06598078
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.22267206 0.06496820
playsound minecraft:entity.elder_guardian.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.83050847 0.06456688
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.91183879 0.06290860
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.33640553 0.04051779
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.58693652 0.03879032
playsound minecraft:entity.guardian.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 2.00000000 0.03267110
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.97727273 0.02974190
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.68539326 0.02540051
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.69426752 0.02468010
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.69426752 0.02351808
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.78195489 0.02173206
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.58139535 0.01449343
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 2.00000000 0.01182654

schedule function lil.tecca.-.dark.thoughts.official.video-20-62-127-:_/1022 2t append