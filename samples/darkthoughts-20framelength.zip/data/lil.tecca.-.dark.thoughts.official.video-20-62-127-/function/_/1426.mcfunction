# 2C-CLIENT PROPERTY

execute run stopsound @a[tag=!nomusic,tag=!nm] record
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.62039046 0.36501497
playsound minecraft:block.bamboo_wood_button.click_on record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.01689069 0.28011256
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.61686233 0.15962550
playsound minecraft:block.note_block.bass record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.95367847 0.14874245
playsound minecraft:block.cherry_wood_button.click_on record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.88928994 0.14078860
playsound minecraft:entity.item.pickup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.59224219 0.11405431
playsound minecraft:block.cherry_wood_button.click_off record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.08379888 0.11270070
playsound minecraft:block.note_block.bass record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.58693652 0.10821939
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 2.00000000 0.09256715
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.71165644 0.04723948
playsound minecraft:entity.zombie_villager.cure record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.03105590 0.04460809
playsound minecraft:entity.zombie_villager.cure record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.48663102 0.03639128
playsound minecraft:entity.item.pickup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.63169897 0.03587687
playsound minecraft:entity.zombie_villager.cure record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.06188925 0.02920123
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.85972851 0.02863129
playsound minecraft:entity.copper_golem_weathered.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.65819568 0.02781793
playsound minecraft:entity.copper_golem_weathered.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.62403528 0.02636762
playsound minecraft:entity.generic.small_fall record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.81724846 0.02594276
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.27586207 0.02418469
playsound minecraft:entity.zombie_villager.cure record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.89320388 0.02291945
playsound minecraft:entity.zombie_villager.cure record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.58139535 0.02245126
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.48663102 0.02196912
playsound minecraft:entity.zombie_villager.cure record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.13357401 0.02097031
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.33640553 0.01667863

schedule function lil.tecca.-.dark.thoughts.official.video-20-62-127-:_/1427 2t append