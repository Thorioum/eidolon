# 2C-CLIENT PROPERTY

execute run stopsound @a[tag=!nomusic,tag=!nm] record
playsound minecraft:block.note_block.bass record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.50074368 0.13281810
playsound minecraft:block.note_block.bass record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.77148080 0.09319295
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.58139535 0.02693245
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.91183879 0.02104000

schedule function lil.tecca.-.dark.thoughts.official.video-20-62-127-:_/141 2t append