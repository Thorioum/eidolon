# 2C-CLIENT PROPERTY

execute run stopsound @a[tag=!nomusic,tag=!nm] record
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.59785784 0.79406440
playsound minecraft:block.note_block.bass record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.17557252 0.33900738
playsound minecraft:block.cherry_wood_button.click_off record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.46952224 0.28098706
playsound minecraft:block.note_block.bass record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.67950481 0.24559025
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.33640553 0.15086840
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.70464768 0.13471903
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.95367847 0.10916094
playsound minecraft:entity.item.pickup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.75216638 0.10035835
playsound minecraft:entity.item.pickup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.69153515 0.09632630
playsound minecraft:block.note_block.bass record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.83098592 0.08714020
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.48663102 0.08092781
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.06188925 0.08052748
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.50074368 0.07844490
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.57487091 0.07581357
playsound minecraft:entity.zombie_villager.cure record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.33640553 0.06315669
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.83098592 0.03684092
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.03105590 0.03371415

schedule function lil.tecca.-.dark.thoughts.official.video-20-62-127-:_/121 2t append