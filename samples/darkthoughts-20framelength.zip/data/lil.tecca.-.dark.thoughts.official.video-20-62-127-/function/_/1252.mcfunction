# 2C-CLIENT PROPERTY

execute run stopsound @a[tag=!nomusic,tag=!nm] record
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.95367847 0.84913474
playsound minecraft:block.note_block.bass record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.40594059 0.58622980
playsound minecraft:entity.item.pickup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.65336658 0.28890568
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.65819568 0.26270369
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.81724846 0.22850364
playsound minecraft:block.note_block.bass record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.91183879 0.21888760
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.40594059 0.15007901
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.61344538 0.14118926
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.63990555 0.14061855
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.58439201 0.13469358
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.50074368 0.13366754
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.00296736 0.12003207
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.56628478 0.11338332
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.80478088 0.09312453
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.84463895 0.05531370

schedule function lil.tecca.-.dark.thoughts.official.video-20-62-127-:_/1253 2t append