# 2C-CLIENT PROPERTY

execute run stopsound @a[tag=!nomusic,tag=!nm] record

schedule function lil.tecca.-.dark.thoughts.official.video-20-62-127-:_/1 2t append