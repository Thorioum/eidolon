# 2C-CLIENT PROPERTY

execute run stopsound @a[tag=!nomusic,tag=!nm] record
playsound minecraft:block.note_block.bass record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.00296736 0.41223279
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.50544888 0.34038165
playsound minecraft:block.note_block.bass record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.59500960 0.18542832
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.58139535 0.12172265
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.50074368 0.10507901
playsound minecraft:entity.guardian.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.58139535 0.06904035
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.58955224 0.06356641
playsound minecraft:block.note_block.bass record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.09589041 0.05995671
playsound minecraft:entity.elder_guardian.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.95367847 0.05961329
playsound minecraft:block.note_block.bass record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.48663102 0.04812184
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.69426752 0.04750606
playsound minecraft:block.anvil.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.91183879 0.04041511
playsound minecraft:entity.item.pickup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.83050847 0.03941652
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.72668810 0.03587854
playsound minecraft:entity.bogged.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.54042847 0.03256506
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.22267206 0.02771400
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.17557252 0.02725756
playsound minecraft:entity.copper_golem_weathered.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.57487091 0.02625646
playsound minecraft:entity.firework_rocket.blast record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.58955224 0.02609357
playsound minecraft:entity.copper_golem_weathered.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.54340155 0.02562567
playsound minecraft:entity.bogged.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.78195489 0.02485755
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.58139535 0.02441246
playsound minecraft:entity.player.levelup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.50971922 0.02340718
playsound minecraft:entity.guardian.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.69426752 0.02207746
playsound minecraft:entity.zombie_villager.cure record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.17557252 0.02197204
playsound minecraft:entity.bogged.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.50544888 0.02173966
playsound minecraft:block.anvil.destroy record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.50463440 0.02144508
playsound minecraft:block.anvil.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.51532350 0.02029853
playsound minecraft:entity.copper_golem_weathered.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.51732102 0.02012458
playsound minecraft:entity.copper_golem_weathered.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.69153515 0.02003104
playsound minecraft:entity.copper_golem_weathered.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.89320388 0.02002766
playsound minecraft:block.anvil.destroy record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.64423077 0.01898611
playsound minecraft:entity.copper_golem_weathered.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.81724846 0.01842947
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.84463895 0.01834933
playsound minecraft:block.anvil.destroy record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.60381143 0.01714173
playsound minecraft:block.anvil.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.57264231 0.01634465
playsound minecraft:block.anvil.destroy record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.51732102 0.01618705
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.91183879 0.01599468
playsound minecraft:block.anvil.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.85972851 0.01507181
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.81724846 0.01440051
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.87587822 0.01371924
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.17557252 0.01336878
playsound minecraft:block.anvil.destroy record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.76156584 0.01271582
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.33640553 0.01266900
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.51152580 0.01265190
playsound minecraft:block.anvil.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.58139535 0.01235016
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 2.00000000 0.01123415
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.48663102 0.01098150
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.55487805 0.01057374
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.33640553 0.00957677

schedule function lil.tecca.-.dark.thoughts.official.video-20-62-127-:_/1040 2t append