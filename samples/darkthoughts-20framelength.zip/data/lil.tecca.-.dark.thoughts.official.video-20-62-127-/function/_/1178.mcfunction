# 2C-CLIENT PROPERTY

execute run stopsound @a[tag=!nomusic,tag=!nm] record
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.83098592 0.72389740
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.40594059 0.31866869
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.69426752 0.29066724
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.76156584 0.23766663
playsound minecraft:entity.guardian.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.83098592 0.19198799
playsound minecraft:entity.elder_guardian.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.97727273 0.17555553
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.83098592 0.15691055
playsound minecraft:entity.guardian.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.22267206 0.14833575
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.13357401 0.14730063
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 2.00000000 0.12616082
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.73476112 0.12412620
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.71899529 0.12076183
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.40594059 0.11210544
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.66842801 0.09374924
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.50074368 0.09270802
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.48663102 0.09193199
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.93193717 0.08319502
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 2.00000000 0.07946313
playsound minecraft:entity.copper_golem_weathered.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.58955224 0.07742970
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.63169897 0.07640944
playsound minecraft:entity.elder_guardian.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.97727273 0.07569756
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.60381143 0.06994608
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.93193717 0.06887600
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.40594059 0.06761300
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.17557252 0.05146340
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.58139535 0.04283718
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.75216638 0.03939481
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 2.00000000 0.02677987

schedule function lil.tecca.-.dark.thoughts.official.video-20-62-127-:_/1179 2t append