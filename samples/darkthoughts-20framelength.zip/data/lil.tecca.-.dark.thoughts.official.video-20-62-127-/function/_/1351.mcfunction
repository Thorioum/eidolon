# 2C-CLIENT PROPERTY

execute run stopsound @a[tag=!nomusic,tag=!nm] record
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 2.00000000 0.13801062
playsound minecraft:block.note_block.bass record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.87587822 0.13649268
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.97727273 0.12912451
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.79303675 0.12912114
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.66842801 0.10894586
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.52489244 0.08070608
playsound minecraft:block.note_block.bass record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.33640553 0.06791713
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.17557252 0.06479190
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.69426752 0.06365920
playsound minecraft:entity.item.pickup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.79303675 0.05054412
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 2.00000000 0.04785856
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.61013444 0.04772047
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.69426752 0.04431477
playsound minecraft:entity.item.pickup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.75216638 0.04023601
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.48663102 0.03830981
playsound minecraft:block.note_block.banjo record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.17557252 0.03756602
playsound minecraft:block.shulker_box.open record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.83098592 0.03657335
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.83098592 0.03517110
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.67950481 0.03480388
playsound minecraft:entity.zombie_villager.cure record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.69426752 0.03205333
playsound minecraft:entity.guardian.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 2.00000000 0.02937173
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.66321244 0.02748764
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.13357401 0.02636501
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.61686233 0.02502275
playsound minecraft:entity.copper_golem_weathered.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.62039046 0.02415521
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.40594059 0.02279500
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.53619303 0.02098774
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.58139535 0.01828838
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.09589041 0.01777860
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.87587822 0.01579754
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.33640553 0.01526156
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.09589041 0.01431629
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.00296736 0.01376466

schedule function lil.tecca.-.dark.thoughts.official.video-20-62-127-:_/1352 2t append