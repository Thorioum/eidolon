# 2C-CLIENT PROPERTY

execute run stopsound @a[tag=!nomusic,tag=!nm] record
playsound minecraft:block.cherry_wood_button.click_off record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.86387435 0.89837997
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.66321244 0.53559476
playsound minecraft:block.nether_wood_button.click_off record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.08987161 0.46230796
playsound minecraft:block.nether_wood_button.click_off record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.00000000 0.30789347
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.77148080 0.28330374
playsound minecraft:block.nether_wood_button.click_off record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.08987161 0.23714591
playsound minecraft:entity.creaking.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.62403528 0.21984190
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.09589041 0.18259561
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.58139535 0.15767580
playsound minecraft:entity.item.pickup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.03105590 0.14036675
playsound minecraft:entity.item.pickup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.50074368 0.12688167
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.27586207 0.09684961
playsound minecraft:entity.zombie_villager.cure record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.58139535 0.08229668
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.95367847 0.07767505
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.00296736 0.07570398
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.83098592 0.07196053
playsound minecraft:entity.item.pickup record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.95367847 0.06623142
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.57715780 0.06361728
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.55666924 0.06250720
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.58955224 0.06211415
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.51152580 0.06067947
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.97727273 0.05889514
playsound minecraft:block.shulker_box.open record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.33640553 0.05870157
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.22267206 0.05825514
playsound minecraft:entity.zombie_villager.cure record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.48663102 0.04937098
playsound minecraft:entity.creaking.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.71165644 0.04928477
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.17557252 0.04831180
playsound minecraft:entity.iron_golem.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.64871481 0.04718920
playsound minecraft:entity.skeleton_horse.jump_water record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.33640553 0.04563129
playsound minecraft:block.conduit.deactivate record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.00296736 0.04532488
playsound minecraft:block.note_block.cow_bell record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.91183879 0.04444438
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 2.00000000 0.04381155
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.17557252 0.04019007
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.48663102 0.03232341
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.06188925 0.02990825
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.69794721 0.02820889
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 2.00000000 0.02389907
playsound minecraft:entity.horse.land record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.27586207 0.02266240
playsound minecraft:block.note_block.basedrum record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 0.62403528 0.02036256
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.69426752 0.02030198
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 2.00000000 0.01735083
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 2.00000000 0.01547880
playsound minecraft:entity.wither.death record @a[tag=!nomusic,tag=!nm] ~ -9999 ~ 1 1.48663102 0.01431114

schedule function lil.tecca.-.dark.thoughts.official.video-20-62-127-:_/1003 2t append