# 2C-CLIENT PROPERTY

execute run stopsound @a[tag=!nomusic,tag=!nm] record

schedule function audio.rick.mp3-20-62-127-:_/10406 2t append